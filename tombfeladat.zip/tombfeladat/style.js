const data = [];

    function addData() {
      const inputElement = document.getElementById('dataInput');
      const inputValue = inputElement.value.trim();

      if (inputValue !== '') {
        data.push(inputValue);
        inputElement.value = '';
        renderData();
      }
    }

    function renderData() {
      const outputElement = document.getElementById('output');
      outputElement.innerHTML = '';

      data.forEach((item, index) => {
        const card = document.createElement('div');
        card.classList.add('card');
        card.innerHTML = `<p>${item}</p>`;
        outputElement.appendChild(card);
      });
    }